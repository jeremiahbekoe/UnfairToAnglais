# Unfair To Anglais

**Unfair To Anglais** is a Chrome extension that translates text with AI, with **no setup for users** (no API key needed).
Two parts: a Manifest V3 extension (vanilla JS) and a small Cloudflare Worker that holds the API key.

![Popup demo](screenshots/popup.png)
![Right-click overlay demo](screenshots/overlay.png)

## Features
- Side panel that stays open while you browse, with 18 languages, auto-detect, swap, copy and Ctrl/Cmd+Enter
- Right-click translation on any page, shown in an isolated Shadow DOM overlay (Esc to close)
- **Tone control**: Neutral, Formal, Casual, Friendly or Simple words
- **Explain this**: a short AI tutor note on word choices, idioms and grammar
- Remembers your last-used languages and tone

## Architecture
```
Side panel / page overlay  ->  background service worker  ->  Cloudflare Worker (holds key)  ->  OpenAI
```
| Path | Role |
|---|---|
| `extension/` | The Chrome extension (load this folder in Chrome) |
| `worker/` | Serverless API proxy with rate limiting and input validation |

## Run it
**Extension:** open `chrome://extensions`, enable Developer mode, **Load unpacked**, choose `extension/`.
**Backend:** see [`worker/README.md`](worker/README.md) to deploy your own, then set `API_BASE` in `extension/background.js`.

## Security decisions
- The OpenAI key exists only as a Cloudflare secret, never in the extension or this repo
- Backend: per-IP rate limiting, 2,000-char cap, allow-listed languages/tones, generic upstream errors, CORS limited to extensions
- Extension: least-privilege permissions, model output rendered with `textContent` (no XSS)
- Prompts wrap user text in tags and tell the model to ignore instructions inside it (prompt-injection mitigation)

## Why not just use Google Translate?
This is a learning project, but the AI approach allows things a plain translator can't: choosing a tone
and asking *why* something was translated the way it was.

## Limitations and next steps
- Rate limiting is a loose per-location filter; a production service would add accounts or stronger quotas
- Ideas: translate whole page, history panel, TypeScript + Vite, automated tests

## Licence
MIT
