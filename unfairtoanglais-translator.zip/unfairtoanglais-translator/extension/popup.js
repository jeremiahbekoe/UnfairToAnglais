const LANGUAGES = ["English","Spanish","French","German","Italian","Portuguese","Dutch","Polish",
  "Russian","Turkish","Arabic","Hindi","Chinese (Simplified)","Japanese","Korean","Yoruba","Twi","Swahili"];

const $ = (id) => document.getElementById(id);
const source = $("source"), target = $("target"), tone = $("tone"), input = $("input");
const go = $("go"), output = $("output"), actions = $("actions");
const copyBtn = $("copy"), explainBtn = $("explain"), explanation = $("explanation");

let last = null; // the most recent successful translation, used by "Explain this"

function fill(select, withAuto) {
  const opts = (withAuto ? [["auto", "Detect language"]] : []).concat(LANGUAGES.map((l) => [l, l]));
  for (const [value, label] of opts) select.add(new Option(label, value));
}
fill(source, true);
fill(target, false);

// Restore last-used settings
chrome.storage.local.get(["source", "target", "tone"]).then((s) => {
  source.value = s.source || "auto";
  target.value = s.target || "English";
  tone.value = s.tone || "neutral";
});

function showOutput(text, isError = false) {
  output.textContent = text;           // textContent (not innerHTML) = no XSS from model output
  output.classList.toggle("error", isError);
  actions.hidden = isError || !text;
  explanation.hidden = true;
  explanation.textContent = "";
}

async function run() {
  const text = input.value.trim();
  if (!text) return showOutput("Enter some text first.", true);
  chrome.storage.local.set({ source: source.value, target: target.value, tone: tone.value });

  go.disabled = true;
  go.firstChild.textContent = "Translating… ";
  showOutput("");
  const res = await chrome.runtime.sendMessage({
    type: "translate", text, source: source.value, target: target.value, tone: tone.value
  });
  go.disabled = false;
  go.firstChild.textContent = "Translate ";

  if (res.ok) {
    last = { original: text, translation: res.text, source: source.value, target: target.value };
    showOutput(res.text);
  } else {
    last = null;
    showOutput(res.error, true);
  }
}

async function runExplain() {
  if (!last) return;
  explainBtn.disabled = true;
  explanation.hidden = false;
  explanation.classList.remove("error");
  explanation.textContent = "Thinking…";
  const res = await chrome.runtime.sendMessage({ type: "explain", ...last });
  explainBtn.disabled = false;
  explanation.classList.toggle("error", !res.ok);
  explanation.textContent = res.ok ? res.text : res.error;
}

go.addEventListener("click", run);
explainBtn.addEventListener("click", runExplain);
input.addEventListener("keydown", (e) => { if (e.key === "Enter" && (e.ctrlKey || e.metaKey)) run(); });

$("swap").addEventListener("click", () => {
  if (source.value === "auto") return;
  [source.value, target.value] = [target.value, source.value];
});

copyBtn.addEventListener("click", async () => {
  await navigator.clipboard.writeText(output.textContent);
  copyBtn.textContent = "Copied ✓";
  setTimeout(() => (copyBtn.textContent = "Copy"), 1200);
});

