// Shows the translation of right-clicked text in a small overlay.
// Shadow DOM keeps our styles isolated from the host page.
let host;

function removeOverlay() { host?.remove(); host = null; }

function showOverlay(message, isError = false) {
  removeOverlay();
  host = document.createElement("div");
  const root = host.attachShadow({ mode: "closed" });
  root.innerHTML = `
    <style>
      .box { position:fixed; top:20px; right:20px; z-index:2147483647; max-width:360px;
        padding:14px 16px; background:#1d222a; color:#eef1f5; border:1px solid #2c333d;
        border-radius:10px; font:14px/1.5 system-ui,sans-serif; box-shadow:0 8px 30px rgba(0,0,0,.4); }
      .box.err { color:#ff8a80; } p { margin:0; white-space:pre-wrap; }
      button { position:absolute; top:4px; right:8px; background:none; border:0; color:#8b95a3; font-size:18px; cursor:pointer; }
    </style>
    <div class="box ${isError ? "err" : ""}"><button aria-label="Close">×</button><p></p></div>`;
  root.querySelector("p").textContent = message;
  root.querySelector("button").addEventListener("click", removeOverlay);
  document.documentElement.appendChild(host);
}

chrome.runtime.onMessage.addListener(async (msg) => {
  if (msg.type !== "show-translation") return;
  showOverlay("Translating…");
  const { target } = await chrome.storage.local.get("target");
  const res = await chrome.runtime.sendMessage({
    type: "translate", text: msg.text, source: "auto", target: target || "English"
  });
  res.ok ? showOverlay(res.text) : showOverlay(res.error, true);
});

document.addEventListener("keydown", (e) => { if (e.key === "Escape") removeOverlay(); });
