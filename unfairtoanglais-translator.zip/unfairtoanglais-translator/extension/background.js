// Service worker: sends requests to our own backend (a Cloudflare Worker).
// The OpenAI key lives on that server, so users never need an API key.
//
// Your deployed worker URL (no trailing slash):
const API_BASE = "https://ai-translator-api.jeremiahbekoe16.workers.dev";

async function post(path, body) {
  const res = await fetch(`${API_BASE}${path}`, {
    method: "POST",
    headers: { "content-type": "application/json" },
    body: JSON.stringify(body)
  });
  const data = await res.json().catch(() => ({}));
  if (!res.ok) throw new Error(data.error || `Request failed (${res.status})`);
  return data.text;
}

const translate = ({ text, source, target, tone = "neutral" }) =>
  post("/translate", { text, source, target, tone });

const explain = ({ original, translation, source, target }) =>
  post("/explain", { original, translation, source, target });

const handlers = { translate, explain };

// Clicking the toolbar icon opens the side panel, which stays open while you browse.
chrome.sidePanel.setPanelBehavior({ openPanelOnActionClick: true }).catch(console.error);

chrome.runtime.onMessage.addListener((msg, _sender, sendResponse) => {
  const handler = handlers[msg.type];
  if (!handler) return;
  handler(msg)
    .then((text) => sendResponse({ ok: true, text }))
    .catch((e) => sendResponse({ ok: false, error: e.message }));
  return true; // keep the channel open for the async response
});

chrome.runtime.onInstalled.addListener(() => {
  chrome.contextMenus.create({
    id: "translate-selection",
    title: "Translate “%s” with Unfair To Anglais",
    contexts: ["selection"]
  });
});

chrome.contextMenus.onClicked.addListener((info, tab) => {
  if (info.menuItemId === "translate-selection" && tab?.id) {
    chrome.tabs.sendMessage(tab.id, { type: "show-translation", text: info.selectionText });
  }
});
