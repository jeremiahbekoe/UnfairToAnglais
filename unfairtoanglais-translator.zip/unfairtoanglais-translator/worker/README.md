# Unfair To Anglais API (Cloudflare Worker)

A small proxy that holds the OpenAI key so extension users don't need their own.

## Deploy (about 10 minutes)
1. Create a free account at https://dash.cloudflare.com
2. In this folder, install and log in:
   ```bash
   npm install -g wrangler        # or use: npx wrangler@latest <command>
   wrangler login
   ```
3. Store your OpenAI key as a **secret** (never put it in a file):
   ```bash
   wrangler secret put OPENAI_API_KEY
   ```
   Paste the key when asked.
4. Deploy:
   ```bash
   wrangler deploy
   ```
   It prints a URL like `https://ai-translator-api.<your-subdomain>.workers.dev`
5. Copy that URL into `API_BASE` at the top of `extension/background.js`.

## Protecting your credits
- **Set a monthly spending limit** in the OpenAI dashboard (Billing > Limits). Do this first.
- Per-IP rate limit: 10 requests/minute (see `wrangler.toml`). It is a loose filter, not a strict guarantee.
- Text capped at 2,000 characters; languages and tones are checked against fixed lists.
- Optional: set `ALLOWED_EXTENSION_ID` in `wrangler.toml` to your extension's ID (shown on `chrome://extensions`).
  Note this only stops other websites using the API from a browser; it cannot stop a determined script.
  The spending limit is your real safety net.
- Upstream errors are never passed to the client.

## Endpoints
- `POST /translate` with `{text, source, target, tone}` returns `{text}`
- `POST /explain` with `{original, translation, source, target}` returns `{text}`
